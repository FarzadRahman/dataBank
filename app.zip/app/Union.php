<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Union extends Model
{
    //
    protected $table='union';
    protected $primaryKey='unionId';
    public $timestamps=false;
}
