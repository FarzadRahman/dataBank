<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MohanogorFile extends Model
{
    protected $table='mohanogofile';
    protected $primaryKey='mohanogorId';
    public $timestamps=false;
}
