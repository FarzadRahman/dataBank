<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Pouroshova extends Model
{
    protected $table='pouroshova';
    protected $primaryKey='pouroshovaId';
    public $timestamps=false;
}
