<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Zillafile extends Model
{
    protected $table='zillafile';
    protected $primaryKey='zillafileId';
    public $timestamps=false;
}
