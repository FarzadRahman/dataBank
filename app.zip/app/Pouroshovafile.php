<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Pouroshovafile extends Model
{
    protected $table='pouroshovafile';
    protected $primaryKey='pouroshovafileId';
    public $timestamps=false;
}
