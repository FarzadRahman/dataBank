<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Zilla extends Model
{

    protected $table='zilla';
    protected $primaryKey='zillaId';
    public $timestamps=false;
}
