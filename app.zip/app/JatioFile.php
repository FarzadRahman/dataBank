<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class JatioFile extends Model
{
    protected $table='jatiofile';
    protected $primaryKey='jatiofileId';
    public $timestamps=false;
}
