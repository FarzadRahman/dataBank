<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Upzilla extends Model
{
    //
    protected $table='upzilla';
    protected $primaryKey='upzillaId';
    public $timestamps=false;
}
