<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Unionfile extends Model
{
    //
    protected $table='unionfile';
    protected $primaryKey='unionfileId';
    public $timestamps=false;
}
