<?php

define('GENDER',array(
    "Male"=>'M',
    "Female"=>'F'
));
define('DISABILITY',array(
    "Yes"=>'Y',
    "No"=>'N'
));
define('PASSPORT',array(
    "Yes"=>'Y',
    "No"=>'N'
));
define('BLOOD_GROUP',array(
    "A+"=>'a+',
    "A-"=>'a-',
    "B+"=>'b+',
    "B-"=>'b-',
    "AB+"=>'ab+',
    "AB-"=>'ab-',
    "O+"=>'o+',
    "O-"=>'o-',
));

define('MARITAL_STATUS',array(
    "Single"=>'s',
    "Married"=>'m',
    "Divorced"=>'d',
    "Widowed"=>'w',
));

define('COMPLETING_STATUS',array(
    "OnGoing"=>'1',
    "Completed"=>'2'
));

define('JOB_STATUS',array(
    "Posted"=>'1',
    "De-activate"=>'2',
));
define('UNIVERSITY_TYPE',array(
    "Private"=>'1',
    "Public"=>'2',
));

define('RESULT_SYSTEM',array(
    "grade"=>'1',
    "division"=>'2',
    "class"=>'3'
));

define('USER_TYPE',array(
    "Admin"=>'admin',
    "Emp"=>'cbEmp',
    "User"=>'user',

));
define('CAREER_QUES',array(
    "Ques1"=>'Why Do You Want to Leave Your Current Job?',
    "Ques2"=>'Why you are intersted for the position applied for?',

));

define('STATUS',array(
    "1"=>'Active',
    "0"=>'Inactive',


));
define('OTHERS',"others");







