<?php $__env->startSection('content'); ?>
<?php $__env->startSection('header'); ?>

    <!-- DataTables -->
    <link href="<?php echo e(url('assets/plugins/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(url('assets/plugins/datatables/buttons.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(url('assets/plugins/datatables/responsive.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />



<?php $__env->stopSection(); ?>
    <!-- Button to Open the Modal -->


    <!-- The Modal -->
    <div class="modal" id="voteModal">
        <div class="modal-dialog">
            <div class="modal-content">

                <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title">Voters</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>

                <!-- Modal body -->
                <div class="modal-body" id="voteModalBody">

                </div>

                <!-- Modal footer -->
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                </div>

            </div>
        </div>
    </div>

    
    <div class="modal" id="centerModal">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">

                <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title">Centers</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>

                <!-- Modal body -->
                <div class="modal-body" id="centerModalBody">

                </div>

                <!-- Modal footer -->
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                </div>

            </div>
        </div>
    </div>

<div style=" margin: 0px; padding: 10px;">
    <br class="mobile-break">
    <br class="mobile-break">
    <br class="mobile-break">
    <div class="card">
        <div class="card-header">
            <h3 align="center">Constituency</h3>
            <i class="glyphicon glyphicon-chevron-right"></i>
        </div>

        <div class="card-body">
            <a href="<?php echo e(route('constituency.add')); ?>" class="btn btn-sm btn-success pull-right"><i class="fa fa-plus"></i></a>
            <div class="table-responsive">
                <table class="table table-striped " id="datatable">
                    <thead>
                    <th>number</th>
                    <th>name</th>
                    <th>area</th>
                    <th>division</th>
                    <th>voter</th>
                    <th>center</th>
                    <th>candidates</th>
                    <th>action</th>
                    </thead>
                    <tbody>

                    </tbody>
                </table>


            </div>

        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('foot-js'); ?>
    <script src="<?php echo e(url('public/assets/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(url('public/assets/plugins/datatables/dataTables.bootstrap4.min.js')); ?>"></script>
    <!-- Buttons examples -->
    <script src="<?php echo e(url('public/assets/plugins/datatables/dataTables.buttons.min.js')); ?>"></script>
    
    
    
    <script>


        $(document).ready( function () {
            dataTable=  $('#datatable').DataTable({
                rowReorder: {
                    selector: 'td:nth-child(0)'
                },
                responsive: true,
                processing: true,
                serverSide: true,
                Filter: true,
                stateSave: true,
                ordering:false,
                type:"POST",
                "ajax":{
                    "url": "<?php echo route('constituency.getConstituencyData'); ?>",
                    "type": "POST",
                    data:function (d){
                        d._token="<?php echo e(csrf_token()); ?>";
                    },
                },
                columns: [
                    { data: 'number', name: 'constituency.number' },
                    { data: 'name', name: 'constituency.name' },
                    { data: 'area', name: 'constituency.area' },
                    { data: 'divisionName', name: 'division.divisionName' },
                    { "data": function(data){
                                return '<button type="button" class="btn btn-primary btn-sm" data-panel-id="'+data.constituencyId+'" onclick="getVoter(this)">' +
                                    data.totalVoter.toString().getDigitBanglaFromEnglish() +
                                    '</button>';
                                },
                        "orderable": false, "searchable":false, "name":"selected_rows" },
                    { "data": function(data){
                            return '<button type="button" class="btn btn-primary btn-sm" data-panel-id="'+data.constituencyId+'"  onclick="centerModal(this)">' +
                                data.totalCenter.toString().getDigitBanglaFromEnglish() +
                                '</button>';
                        },
                        "orderable": false, "searchable":false, "name":"selected_rows" },
                    { "data": function(data){

                            return '<button type="button" class="btn btn-primary btn-sm" data-panel-id="'+data.constituencyId+'" onclick="getCandidates(this)">' +
                                data.totalCandidate.toString().getDigitBanglaFromEnglish()+
                                '</button>';

                        },
                        "orderable": false, "searchable":false, "name":"selected_rows" },
                    { "data": function(data){
                            return '<button type="button" class="btn btn-primary btn-sm"  data-panel-id="'+data.constituencyId+'" onclick="editConsitituency(this)">' +
                               'Edit'+
                                '</button>';
                        },
                        "orderable": false, "searchable":false, "name":"selected_rows" }
                ]
            }

            );

        } );
        var finalEnlishToBanglaNumber={'0':'০','1':'১','2':'২','3':'৩','4':'৪','5':'৫','6':'৬','7':'৭','8':'৮','9':'৯'};
        String.prototype.getDigitBanglaFromEnglish = function() {
            var retStr = this;

            for (var x in finalEnlishToBanglaNumber) {
                retStr = retStr.replace(new RegExp(x, 'g'), finalEnlishToBanglaNumber[x]);
            }
            return retStr;
        };

        function getVoter(x) {
            var id=$(x).data('panel-id');
            $.ajax({
                type: 'POST',
                url: "<?php echo route('constituency.getConstituencyVoter'); ?>",
                cache: false,
                data: {_token: "<?php echo e(csrf_token()); ?>",'id': id},
                success: function (data) {
                    $("#voteModalBody").html(data);
                    $("#voteModal").modal();

                }
            });
        }
        function centerModal(x) {

            var id=$(x).data('panel-id');
            $.ajax({
                type: 'POST',
                url: "<?php echo route('center.getCenterModal'); ?>",
                cache: false,
                data: {_token: "<?php echo e(csrf_token()); ?>",'id': id},
                success: function (data) {
                    $("#centerModalBody").html(data);
                    $("#centerModal").modal();

                }
            });
        }

        function editConsitituency(x) {
            var id=$(x).data('panel-id');
            let url = "<?php echo e(route('constituency.edit', ':id')); ?>";
            url = url.replace(':id', id);
            document.location.href=url;
        }
        function getCandidates(x) {
            var id=$(x).data('panel-id');
            let url = "<?php echo e(route('candidates.index', ':id')); ?>";
            url = url.replace(':id', id);
            document.location.href=url;
        }


    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>