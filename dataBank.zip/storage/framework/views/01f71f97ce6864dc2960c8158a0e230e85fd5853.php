<h5 align="center"><?php echo e($consitituencyName); ?></h5>
<table class="table">
    <thead>
    <th>Center Name</th>
    <th>Total Voter</th>
    </thead>
    <?php
    $bn = array("১", "২", "৩", "৪", "৫", "৬", "৭", "৮", "৯", "০");
    $en = array("1", "2", "3", "4", "5", "6", "7", "8", "9", "0");


    ?>

    <tbody>
        <?php $__currentLoopData = $centers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $center): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($center->centerName); ?></td>
                <td><?php echo e(str_replace($en,$bn,$center->maleVoter+$center->femaleVoter)); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>