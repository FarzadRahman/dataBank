<?php echo $__env->make('layouts/header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<style>
    .alert-feedback{
        color: red;
    }

</style>
<body>

<!-- Loader -->


<!-- Navigation Bar-->
<header id="topnav">
    <div class="topbar-main">
        <div class="container-fluid">

            <!-- Logo container-->
            <div class="logo">
                <!-- Image Logo -->
                <a href="#" class="logo">
                    <h3>ELOC DETAILS</h3>
                </a>

            </div>
            <!-- End Logo container-->


            <div class="menu-extras topbar-custom">



                <ul class="list-inline float-right mb-0">



                    <!-- User-->
                    <li class="list-inline-item dropdown notification-list">
                        <b style="color: white">USER ADMIN</b>
                        <a class="nav-link dropdown-toggle arrow-none waves-effect nav-user" data-toggle="dropdown" href="#" role="button"
                           aria-haspopup="false" aria-expanded="false">
                            <img src="<?php echo e(url('public/assets/images/users/avatar-1.png')); ?>" alt="user" class="rounded-circle">
                        </a>
                        <div class="dropdown-menu dropdown-menu-right profile-dropdown ">
                            <a class="dropdown-item" href="#"><i class="dripicons-user text-muted"></i> Profile</a>
                            <a class="dropdown-item" href="<?php echo e(route('account.index')); ?>"><i class="dripicons-gear text-muted"></i>Change Password</a>
                            <div class="dropdown-divider"></div>


                            
                            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                               onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                <?php echo e(__('Logout')); ?>

                            </a>


                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                <?php echo e(csrf_field()); ?>

                            </form>
                        </div>
                    </li>
                    <li class="menu-item list-inline-item">
                        <!-- Mobile menu toggle-->
                        <a class="navbar-toggle nav-link">
                            <div class="lines">
                                <span></span>
                                <span></span>
                                <span></span>
                            </div>
                        </a>
                        <!-- End mobile menu toggle-->
                    </li>

                </ul>
            </div>
            <!-- end menu-extras -->

            <div class="clearfix"></div>

        </div> <!-- end container -->
    </div>
    <!-- end topbar-main -->

    <?php echo $__env->make('layouts/navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</header>
<!-- End Navigation Bar-->


<div class="wrapper">
    <div class="container-fluid">
        <?php if(Session::has('message')): ?>
            <p class="alert alert-info"><?php echo e(Session::get('message')); ?></p>
        <?php endif; ?>

        <?php echo $__env->yieldContent('content'); ?>

    </div> <!-- end container -->
</div>
<!-- end wrapper -->

<?php echo $__env->make('layouts/footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>