<?php $__env->startSection('content'); ?>
    <br class="mobile-break">
    <br class="mobile-break">
    <div class="card" style="margin-top: 5%">
        <div class="card-body">
            <div class="row" align="center">
                <div class="col-md-6">
                    <a href="<?php echo e(route('constituency.index')); ?>" class="btn btn-sq-lg btn-primary" style="width: 100%;">
                        <i class="fa fa-user fa-5x"></i><br/>
                        Constituency <br>List
                    </a>
                    <div class="mobile-break">
                        <hr>
                    </div>
                </div>
                <div class="col-md-6">
                    <a href="<?php echo e(route('party.index')); ?>" class="btn btn-sq-lg btn-info" style="width: 100%;">
                        <i class="fa fa-user fa-5x"></i><br/>
                        Commitee <br>List
                    </a>
                </div>
            </div>


        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>