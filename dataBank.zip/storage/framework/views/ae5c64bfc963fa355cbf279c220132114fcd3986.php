<?php $__env->startSection('content'); ?>
    <br class="mobile-break"><br class="mobile-break"><br class="mobile-break">
    
    <a href="<?php echo e(route('constituency.index')); ?>">Constituency</a>
    <i class="fa fa-angle-double-right"></i>
    <a href="<?php echo e(route('constituency.edit',['id'=>$getAssociatesDetails->constituencyId])); ?>"><?php echo e($getAssociatesDetails->constituencyName); ?></a>
    <i class="fa fa-angle-double-right"></i>
    <a href="<?php echo e(route('candidates.index',['id'=>$getAssociatesDetails->constituencyId])); ?>">candidates</a>
    <i class="fa fa-angle-double-right"></i>
    <a href="<?php echo e(route('candidates.edit',['id'=>$getAssociatesDetails->constituencyId])); ?>"><?php echo e($getAssociatesDetails->candidateName); ?></a>
    <i class="fa fa-angle-double-right"></i>Associate :   <?php echo e($getAssociatesDetails->associateName); ?>



    <div class="col-md-12"> <br>

        <div class="card">
            <div class="card-header">
                <h3 class="pull-left">Details Of the Associate</h3>

                <div class="form-group pull-right">
                    <a href="<?php echo e(route('associate.edit',$getAssociatesDetails->associateId)); ?>"><button class="btn btn-sm btn-info">Edit</button></a>
                    <button type="button" class="btn btn-default btn-sm"  onclick="printAssociate(<?php echo e($getAssociatesDetails->associateId); ?>)"><i class="fa fa-print"></i></button>
                </div>


            </div>
            <div class="card-body">

                <div class="row">
                    <div class="col-md-12 ">
                        <div class="form-group">
                            <?php if($getAssociatesDetails->image != null): ?>
                                <div>
                                    <img style="width: 150px;height: 150px" src="<?php echo e(url('public/associate/associateImages/thumb'."/".$getAssociatesDetails->image)); ?>">

                                </div>
                            <?php else: ?>
                                <label for="inputEmail4">Image : NA</label>
                            <?php endif; ?>
                        </div>


                    </div>

                </div>
                
                    <div class="row">
                        <div class="form-group col-md-6">
                            <label for="inputEmail4">Name :</label>
                            <?php echo e($getAssociatesDetails->associateName); ?>

                        </div>
                        <div class="form-group col-md-4">
                            <label for="inputEmail4">Phone Number :</label>
                            <?php echo e($getAssociatesDetails->phoneNumber); ?>

                        </div>
                    </div>
                    <div class="row">
                        <div class="form-group col-md-6">
                            <label for="inputEmail4">party :</label>
                            <?php echo e($getAssociatesDetails->partyName); ?>

                        </div>






                    <div class="row">
                        <div class="form-group col-md-12">
                            <label for="inputEmail4">Remarks :</label>
                            <?php echo e($getAssociatesDetails->remark); ?>

                        </div>

                    </div>
                <hr>
                <?php if($getAssociatesDetails->profile == null): ?>

                    <div class="row">
                        <div class="form-group col-md-6">
                            <label for="inputEmail4">Date of Birth :</label>
                            <?php echo e($getAssociatesDetails->dob); ?>

                        </div>
                        <div class="form-group col-md-6">
                            <label for="inputEmail4">Gender :</label>
                            <?php $__currentLoopData = GENDER; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($getAssociatesDetails->gender==$value): ?><?php echo e($key); ?><?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>
                    </div>
                    <div class="row">
                        <div class="form-group col-md-6">
                            <label for="inputEmail4">Blood Group :</label>
                            <?php echo e($getAssociatesDetails->bloodGroup); ?>

                        </div>
                        <div class="form-group col-md-6">
                            <label for="inputEmail4">NID :</label>
                            <?php echo e($getAssociatesDetails->nid); ?>


                        </div>
                    </div>
                    <div class="row">
                        <div class="form-group col-md-12">
                            <label for="inputEmail4">Address :</label>
                            <?php echo e($getAssociatesDetails->address); ?>

                        </div>

                    </div>

                <?php else: ?>
                            <div align="center"  class="embed-responsive embed-responsive-4by3">
                                <iframe class="embed-responsive-item"   name="myiframe" id="myiframe" src="<?php echo e(url('public/associate/profileDoc'."/".$getAssociatesDetails->profile)); ?>"></iframe>
                            </div>
                <?php endif; ?>


            </div>
        </div>

    </div>






<?php $__env->stopSection(); ?>

<?php $__env->startSection('foot-js'); ?>
            <script>
                function printAssociate(x){
                    var id=x;
                    var url = "<?php echo e(route('pdf.getAssociate', ':id')); ?>";
                    url = url.replace(':id', id);
                    document.location.href=url;

                }
            </script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>