<form method="post" action="<?php echo e(route('partylevel.update')); ?>">
    <input type="hidden" name="id" value="<?php echo e($partyLevels->party_levelId); ?>">
    <?php echo e(csrf_field()); ?>

    <div class="row">
        <div class="form-group col-md-6">
            <label>Level Name</label>
            <input type="text" name="name" value="<?php echo e($partyLevels->name); ?>" placeholder="party level name" class="form-control" required>
        </div>
        <div class="form-group col-md-12">
            <button class="btn btn-success pull-right">Insert</button>
        </div>

    </div>
</form>