<?php $__env->startSection('content'); ?>
    <br class="mobile-break"><br class="mobile-break"><br class="mobile-break">
    
    <a href="<?php echo e(route('constituency.index')); ?>">Constituency</a>
    <i class="fa fa-angle-double-right"></i>
    <a href="<?php echo e(route('constituency.edit',['id'=>$getCandidatesDetails->constituencyId])); ?>"><?php echo e($getCandidatesDetails->constituencyName); ?></a>
    <i class="fa fa-angle-double-right"></i>
    <a href="<?php echo e(route('candidates.index',['id'=>$getCandidatesDetails->constituencyId])); ?>">candidates</a>
    <i class="fa fa-angle-double-right"></i> <?php echo e($getCandidatesDetails->CandidateName); ?>




    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="pull-left">Details Of the Candidate</h3>

                    <div class="form-group pull-right">
                        <a href="<?php echo e(route('candidates.editView',$getCandidatesDetails->candidateId)); ?>"><button class="btn btn-sm btn-info ">Edit</button></a>
                        &nbsp;&nbsp;
                        <button type="button" class="btn btn-default btn-sm"  onclick="printCandidate(<?php echo e($getCandidatesDetails->candidateId); ?>)"><i class="fa fa-print"></i></button>

                    </div>


                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12 ">
                            <div class="form-group">

                                <?php if($getCandidatesDetails->image != null): ?>
                                    <div>
                                        <img style="width: 150px;height: 150px" src="<?php echo e(url('public/candidate/candidateImages/thumb'."/".$getCandidatesDetails->image)); ?>">

                                    </div>
                                    <?php else: ?>
                                    <label for="inputEmail4">Image : NA</label>
                                <?php endif; ?>
                            </div>


                        </div>

                    </div>

                    <div class="row">
                        <div class="form-group col-md-6">
                            <label for="inputEmail4">Name :</label>
                            <?php echo e($getCandidatesDetails->CandidateName); ?>

                        </div>
                        <div class="form-group col-md-4">
                            <label for="inputEmail4">Phone Number :</label>
                            <?php echo e($getCandidatesDetails->phoneNumber); ?>

                        </div>
                    </div>
                        <div class="row">
                            <div class="form-group col-md-6">
                                <label for="inputEmail4">party :</label>
                                <?php echo e($getCandidatesDetails->partyName); ?>

                            </div>
                            <div class="form-group col-md-6">
                                <label for="inputEmail4">Constituency :</label>
                                <?php echo e($getCandidatesDetails->constituencyName); ?>

                            </div>
                        </div>
                        <div class="row">
                            <div class="form-group col-md-12">
                                <label for="inputEmail4">Remarks :</label>
                                <?php echo e($getCandidatesDetails->remark); ?>

                            </div>

                        </div>

                    <hr>

                    <?php if($getCandidatesDetails->profile == null): ?>

                        <div class="row">
                            <div class="form-group col-md-6">
                                <label for="inputEmail4">Date of Birth :</label>
                                <?php echo e($getCandidatesDetails->dob); ?>

                            </div>
                            <div class="form-group col-md-6">
                                <label for="inputEmail4">Gender :</label>
                                <?php $__currentLoopData = GENDER; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($getCandidatesDetails->gender==$value): ?><?php echo e($key); ?><?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>
                        </div>
                        <div class="row">
                            <div class="form-group col-md-6">
                                <label for="inputEmail4">Blood Group :</label>
                                <?php echo e($getCandidatesDetails->bloodGroup); ?>

                            </div>
                            <div class="form-group col-md-6">
                                <label for="inputEmail4">NID :</label>
                                <?php echo e($getCandidatesDetails->nid); ?>


                            </div>
                        </div>
                        <div class="row">
                            <div class="form-group col-md-12">
                                <label for="inputEmail4">Address :</label>
                                <?php echo e($getCandidatesDetails->address); ?>

                            </div>

                        </div>

                        <?php endif; ?>



                </div>
            </div>
            <br>
        </div>

        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    <h3 class=" pull-left" align="center">Associate</h3>
                    <a href="<?php echo e(route('associate.add',$getCandidatesDetails->candidateId)); ?>"><button class="btn btn-sm btn-success pull-right"><i class="fa fa-plus"></i></button></a>
                </div>
                <div class="card-body">

                    <table id="" class="table table-striped manageapplication">
                        <thead>

                        <th>name</th>
                        <th>Phone number</th>
                        <th>Action</th>

                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $getAllAssociate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $associate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <?php echo e($associate->name); ?>

                                </td>
                                <td>
                                    <?php echo e($associate->phoneNumber); ?>

                                </td>
                                <td><a href="<?php echo e(route('associate.view',$associate->associateId)); ?>" class="btn btn-info btn-sm">View</a>
                                    <button type="button" class="btn btn-danger btn-sm " onclick="deleteAssociate(<?php echo e($associate->associateId); ?>)"><i class="fa fa-trash"></i></button>
                                    <button type="button" class="btn btn-default btn-sm"  onclick="printAssociate(<?php echo e($associate->associateId); ?>)"><i class="fa fa-print"></i></button>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                </div>
            </div>


        </div>
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    <h3 class="pull-left" align="center">Promoters</h3>
                    <a href="<?php echo e(route('promoter.add',$getCandidatesDetails->candidateId)); ?>"><button class="btn btn-sm btn-success pull-right"><i class="fa fa-plus"></i></button></a>
                </div>
                <div class="card-body">

                    <table id="" class="table table-striped manageapplication">
                        <thead>

                        <th>name</th>
                        <th>Phone number</th>
                        <th>Action</th>

                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $getPromoters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $promoters): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <?php echo e($promoters->name); ?>

                                </td>
                                <td>
                                    <?php echo e($promoters->phoneNumber); ?>

                                </td>
                                <td><a href="<?php echo e(route('promoter.view',$promoters->promotersId)); ?>" class="btn btn-info btn-sm">View</a>
                                    <button type="button" class="btn btn-danger btn-sm " onclick="deletePromoter(<?php echo e($promoters->promotersId); ?>)"><i class="fa fa-trash"></i></button>
                                    <button type="button" class="btn btn-default btn-sm"  onclick="printPromoters(<?php echo e($promoters->promotersId); ?>)"><i class="fa fa-print"></i></button>

                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                </div>
            </div>


        </div>

    </div>
<br><br>
    <?php if($getCandidatesDetails->profile != null): ?>
        <div align="center"  class="embed-responsive embed-responsive-4by3">
            <iframe class="embed-responsive-item"   name="myiframe" id="myiframe" src="<?php echo e(url('public/candidate/profileDoc'."/".$getCandidatesDetails->profile)); ?>"></iframe>
        </div>
    <?php endif; ?>







<?php $__env->stopSection(); ?>

<?php $__env->startSection('foot-js'); ?>

    <script src="<?php echo e(url('public/assets/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(url('public/assets/plugins/datatables/dataTables.bootstrap4.min.js')); ?>"></script>
    <!-- Buttons examples -->
    <script>
        $(document).ready(function() {
            $('table.manageapplication').DataTable(

                {
                    "ordering": false

                }
            );
        } );
        function deleteAssociate(x){
            $.confirm({
                title: 'Delete!',
                content: 'Are you sure ?',
                buttons: {
                    confirm: function () {
                        $.ajax({
                            type: 'POST',
                            url: "<?php echo route('associate.delete'); ?>",
                            cache: false,
                            data: {_token: "<?php echo e(csrf_token()); ?>",'id': x},
                            success: function (data) {
                                location.reload();

                            }
                        });
                    },
                    cancel: function () {
//                        $.alert('Canceled!');
                    }

                }
            });

        }
        function deletePromoter(x){
            $.confirm({
                title: 'Delete!',
                content: 'Are you sure ?',
                buttons: {
                    confirm: function () {
                        $.ajax({
                            type: 'POST',
                            url: "<?php echo route('promoter.delete'); ?>",
                            cache: false,
                            data: {_token: "<?php echo e(csrf_token()); ?>",'id': x},
                            success: function (data) {
                                location.reload();

                            }
                        });
                    },
                    cancel: function () {
//                        $.alert('Canceled!');
                    }

                }
            });

        }

        function printCandidate(x){
            var id=x;
            var url = "<?php echo e(route('pdf.index', ':id')); ?>";
            url = url.replace(':id', id);
            document.location.href=url;

        }

        function printAssociate(x){
            var id=x;
            var url = "<?php echo e(route('pdf.getAssociate', ':id')); ?>";
            url = url.replace(':id', id);
            document.location.href=url;

        }
        function printPromoters(x){
            var id=x;
            var url = "<?php echo e(route('pdf.getPromoter', ':id')); ?>";
            url = url.replace(':id', id);
            document.location.href=url;

        }
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>