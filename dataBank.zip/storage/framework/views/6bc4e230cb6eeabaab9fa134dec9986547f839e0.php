<?php $__env->startSection('content'); ?>
    <!-- Add Center Modal -->
    <div class="modal" id="addCenterModal">
        <div class="modal-dialog" style="max-width: 70%;">
            <div class="modal-content">

                <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title">Add Center</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>

                <!-- Modal body -->
                <div class="modal-body">
                    <form method="post" action="<?php echo e(route('center.insert')); ?>">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="id" value="<?php echo e($consituency->constituencyId); ?>">
                        <div class="row">
                            <div class="form-group col-md-6">
                                <label>Center Name</label>
                                <input type="text" class="form-control" name="centerName" placeholder="name" required>
                            </div>
                            <div class="form-group col-md-6">
                                <label>Location</label>
                                <textarea class="form-control" name="location" placeholder="location" ></textarea>
                            </div>
                            <div class="form-group col-md-6">
                                <label>Male Voter</label>
                                <input type="number" class="form-control" name="maleVoter" placeholder="male">
                            </div>
                            <div class="form-group col-md-6">
                                <label>Female Voter</label>
                                <input type="number" class="form-control" name="femaleVoter" placeholder="female" >
                            </div>
                            <div class="col-md-12">
                                <button class="btn btn-success btn-sm">Insert</button>
                            </div>
                        </div>
                    </form>

                </div>

                <!-- Modal footer -->
                <div class="modal-footer">

                </div>

            </div>
        </div>
    </div>

    <!--Edit Center Modal -->
    <div class="modal" id="editCenterModal">
        <div class="modal-dialog" style="max-width: 70%;">
            <div class="modal-content">

                <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title">Center</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>

                <!-- Modal body -->
                <div class="modal-body" id="editCenterModalBody">

                </div>

                <!-- Modal footer -->
                <div class="modal-footer">

                </div>

            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-header">
            <h4 align="center">Edit Constituency</h4>
        </div>
        <div class="card-body">
            <form method="post" action="<?php echo e(route('constituency.update',['id'=>$consituency->constituencyId])); ?>" accept-charset="utf-8">
                <?php echo e(csrf_field()); ?>

                <div class="row">
                    <div class="form-group col-md-6">
                        <label>Constituency Number</label>
                        <input type="text" name="number" placeholder="number" class="form-control" value="<?php echo e($consituency->number); ?>" required>
                    </div>
                    <div class="form-group col-md-6">
                        <label>Constituency Name</label>
                        <input type="text" name="name" placeholder="name" class="form-control" value="<?php echo e($consituency->name); ?>" required>
                    </div>
                    <div class="form-group col-md-6">
                        <label>Constituency Area</label>
                        <textarea name="area" class="form-control" placeholder="area" rows="5" required><?php echo e($consituency->area); ?></textarea>
                    </div>
                    <div class="form-group col-md-6">
                        <label>Division</label>
                        <select class="form-control" name="divisionId" required>
                            <option value="">Select Division</option>
                            <?php $__currentLoopData = $divisions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $division): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($division->divisionId); ?>" <?php if($division->divisionId==$consituency->divisionId): ?> selected <?php endif; ?>><?php echo e($division->divisionName); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-12">
                        <hr>
                        <h5 align="center">Voter</h5>
                    </div>
                    <div class="form-group col-sm-4">
                        <label>Male</label>
                        <input class="form-control" name="maleVoter" type="number" value="<?php echo e($consituency->maleVoter); ?>" required>
                    </div>
                    <div class="form-group col-sm-4">
                        <label>Female</label>
                        <input class="form-control" name="femaleVoter" value="<?php echo e($consituency->femaleVoter); ?>" type="number" required>
                    </div>
                    <div class="form-group col-sm-12">
                        <button class="btn btn-success pull-right">Update</button>
                    </div>

                </div>
            </form>


        </div>
    </div>
    <div class="col-md-12"><hr></div>
    <div class="card">
        <div class="card-header">
            <h5 align="center">Center</h5>
            <button class="btn btn-info btn-sm pull-right" onclick="addCenter()"><i class="fa fa-plus"></i></button>
        </div>
        <?php
        $bn = array("১", "২", "৩", "৪", "৫", "৬", "৭", "৮", "৯", "০");
        $en = array("1", "2", "3", "4", "5", "6", "7", "8", "9", "0");


        ?>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                    <th>SL</th>
                    <th>Center Name</th>
                    <th>Location</th>
                    <th>Male Voter</th>
                    <th>Female Voter</th>
                    <th>Total Voter</th>
                    <th>Action</th>
                    </thead>
                    <tbody>
                    <?php ($sl=0); ?>
                    <?php $__currentLoopData = $centers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $center): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e(str_replace($en,$bn,++$sl)); ?></td>
                            <td><?php echo e($center->centerName); ?></td>
                            <td><?php echo e($center->location); ?></td>
                            <td><?php echo e(str_replace($en,$bn,$center->maleVoter)); ?></td>
                            <td><?php echo e(str_replace($en,$bn,$center->femaleVoter)); ?></td>
                            <td><?php echo e(str_replace($en,$bn,$center->maleVoter+$center->femaleVoter)); ?></td>
                            <td><button class="btn btn-sm btn-info" onclick="editCenter(<?php echo e($center->centerId); ?>)">Edit</button></td>
                        </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

            </div>


        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('foot-js'); ?>
    <script>
        function editCenter(x) {
            // editCenterModal
            // $("#editCenterModal").modal();
            $.ajax({
                type: 'POST',
                url: "<?php echo route('center.editCenter'); ?>",
                cache: false,
                data: {_token: "<?php echo e(csrf_token()); ?>",'id': x},
                success: function (data) {
                    $("#editCenterModalBody").html(data);
                    $("#editCenterModal").modal();

                }
            });

        }

        function addCenter() {
            $("#addCenterModal").modal();
        }
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>