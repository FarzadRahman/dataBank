<html>
<head>
    <style>

        table, th, td {
            border: 1px solid black;
            border-collapse: collapse;
        }
        th{
            font-weight: bold;
        }
        th, td {
            padding: 5px;
            text-align: left;
        }

        input {
            border: medium none;
            padding: 0;
        }

        .label{
        background-color: #eff0f1;
        }
        .bold{
            font-weight: bold;
        }
    </style>
</head>


<body>
<meta http-equiv="Content-Type" content="text/html;"/>
<meta charset="UTF-8">



    <div style="position: relative;" class="row ">


        <div class="col-12">
            <div style="" class="card">
                <div class="card-body">
                    

                        <div id="regForm">
                            
                            



                            <table border="0" style="width:100%; margin-top: 10px; border: none;">
                                <tr>
                                    <td style="border: none;"><h2 style="font-size: 24px; border: none; text-align: center"><span style="border-bottom: 1px solid #000">Candidate</span> </h2></td>
                                </tr>

                            </table>

                            <?php if(!empty($candidate->profile) ): ?>
                                <img height="150px" width="150px" src="<?php echo e(url('public/candidate/candidateImages/thumb').'/'.$candidate->image); ?>" alt="">
                                <p style="page-break-after: always"></p>
                            <?php else: ?>

                            <table border="0" style="width:100%; margin-top: 30px; border: none;">
                                <tr>
                                    <td style="text-align: left; border: none;">
                                        <h3 style=""><?php echo e($candidate->cname); ?> </h3>
                                        <p style="max-width: 300px"><span class="bold">Cell No:</span> <?php echo e($candidate->phoneNumber); ?> <br>
                                            <span class="bold">Address:</span> <?php echo e($candidate->address); ?> <br>
                                            
                                        </p>

                                    </td>
                                    <td style="width: 13%; border: none; "><img height="150px" width="150px" src="<?php echo e(url('public/candidate/candidateImages/thumb').'/'.$candidate->image); ?>" alt=""></td>
                                </tr>

                            </table>



                            <table border="0" style="width:100%; margin-top: 25px; border: none;">
                                <tr>
                                    <td class="label" style="text-align: left; border: none; border-bottom: 1px solid #000"><b>Details</b> </td>
                                </tr>
                            </table>


                            

                            <table border="0" style="width:100%; margin-top: 10px; ">
                                <tr>
                                    <th style="text-align: center" >DOB</th>
                                    <td style="text-align: center"><?php echo e($candidate->dob); ?> </td>
                                </tr>
                                <tr>
                                    <th style="text-align: center" >Gender</th>
                                    <td style="text-align: center"><?php echo e($candidate->gender); ?> </td>
                                </tr>
                                <tr>
                                    <th style="text-align: center" >Blood Group</th>
                                    <td style="text-align: center"><?php echo e($candidate->bloodGroup); ?> </td>
                                </tr>
                                <tr>
                                    <th style="text-align: center" >NID</th>
                                    <td style="text-align: center"> <?php echo e($candidate->nid); ?></td>
                                </tr>
                                <tr>
                                    <th style="text-align: center" >Party</th>
                                    <td style="text-align: center"><?php echo e($candidate->partyName); ?> </td>
                                </tr>
                                <tr>
                                    <th style="text-align: center" >Constituency</th>
                                    <td style="text-align: center"><?php echo e($candidate->consname); ?></td>

                                </tr>
                                <tr>
                                    <th style="text-align: center" >Remake</th>
                                    <td style="text-align: center"> <?php echo e($candidate->remark); ?></td>
                                </tr>


                            </table >


                            <table border="0" style="width:100%; margin-top: 15px; border: none;">
                                <tr>
                                    <td class="label" style="text-align: left; border: none; border-bottom: 1px solid #000"><b>Promoters</b> </td>
                                </tr>
                            </table>

                            <?php endif; ?>

                            <table border="0" style="width:100%; margin-top: 10px; border: none;">

                                <?php $count=1;?>
                                <?php $__currentLoopData = $promoters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <tr>
                                        <td width="2%" style="border: none; vertical-align: top">
                                            <span class="bold"><?php echo e($count++); ?>.</span>
                                        </td>


                                        <td style="border: none;">

                                            <span class="bold">Name :</span> &nbsp;&nbsp;&nbsp; <?php echo e($prm->proname); ?> <br>
                                            <span class="bold">Phone Number:</span>&nbsp;&nbsp;&nbsp; <?php echo e($prm->pronumber); ?> <br>

                                        </td>
                                    </tr>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </table>


                            <table border="0" style="width:100%; margin-top: 15px; border: none;">
                                <tr>
                                    <td class="label" style="text-align: left; border: none; border-bottom: 1px solid #000"><b>Associates</b> </td>
                                </tr>
                            </table>


                            <table border="0" style="width:100%; margin-top: 10px; border: none;">

                                <?php $count=1;?>
                                <?php $__currentLoopData = $associates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $associate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <tr>
                                        <td width="2%" style="border: none; vertical-align: top">
                                            <span class="bold"><?php echo e($count++); ?>.</span>
                                        </td>


                                        <td style="border: none;">

                                            <span class="bold">Name :</span> &nbsp;&nbsp;&nbsp; <?php echo e($associate->assoname); ?> <br>
                                            <span class="bold">Phone Number:</span>&nbsp;&nbsp;&nbsp; <?php echo e($associate->assonumber); ?> <br>

                                        </td>
                                    </tr>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </table>

                </div>
            </div>
        </div> <!-- end col -->
    </div> <!-- end row -->

    </div>

</body>
</html>